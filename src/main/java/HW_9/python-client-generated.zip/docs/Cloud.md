# Cloud

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cloud_id** | **str** |  | [optional] 
**id_client** | **str** |  | 
**os** | **str** | Операционна система сервера | 
**ram** | **str** | Объем оперативной памяти | 
**cpu** | **str** | Количество ядер процессора | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

